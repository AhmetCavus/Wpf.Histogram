﻿namespace HistogramUi.Service
{
    /// <summary>
    /// A service for controlling the chart views
    /// </summary>
    public interface IChartService
    {
    }
}
